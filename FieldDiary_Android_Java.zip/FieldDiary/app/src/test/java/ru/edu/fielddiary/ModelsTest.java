package ru.edu.fielddiary;
import org.junit.Test;
import org.json.*;
import java.util.*;
import ru.edu.fielddiary.Models.Record;
import static ru.edu.fielddiary.Models.*;
import static org.junit.Assert.*;

public class ModelsTest {
    private Record card(String q,String a,String image){return new Record(id(),CARD,BIO,obj("question",q,"answer",a,"image",image));}
    private Record entry(JSONObject f,String value){
        return new Record(id(),ENTRY,GEO,obj("title","Проверка","observedAt",1L,
            "fields",new JSONArray().put(f),"values",obj(f.optString("id"),value)));
    }
    private void fails(Runnable code){try{code.run();fail("Ожидалась ошибка проверки");}catch(IllegalArgumentException expected){}}
    @Test public void seedsAreValidAndUnique(){Set<String> ids=new HashSet<>();for(Record r:SeedData.all()){r.validate();assertTrue(ids.add(r.id));}}
    @Test public void subjectsSeparated(){int bio=0,geo=0;for(Record r:SeedData.all()){if(r.subject.equals(BIO))bio++;else if(r.subject.equals(GEO))geo++;}assertEquals(7,bio);assertEquals(7,geo);}
    @Test public void textCardIsValid(){card("Вопрос","Ответ","").validate();}
    @Test public void imageCardIsValid(){card("","Ответ",id()+".jpg").validate();}
    @Test public void cardNeedsFront(){fails(()->card("","Ответ","").validate());}
    @Test public void cardNeedsAnswer(){fails(()->card("Вопрос","","").validate());}
    @Test public void unknownSubjectRejected(){fails(()->new Record(id(),CARD,"other",obj("question","Q","answer","A")).validate());}
    @Test public void unknownKindRejected(){fails(()->new Record(id(),"other",BIO,obj()).validate());}
    @Test public void imageTraversalRejected(){fails(()->card("Q","A","../../photo.jpg").validate());}
    @Test public void duplicateFieldIdsRejected(){JSONObject f=field("Высота","number","см",false,"");fails(()->validateFields(new JSONArray().put(f).put(copy(f))));}
    @Test public void emptyFieldsRejected(){fails(()->validateFields(new JSONArray()));}
    @Test public void choiceNeedsTwoOptions(){fails(()->validateFields(new JSONArray().put(field("Облачность","choice","",true,"Ясно"))));}
    @Test public void choiceCannotHaveEmptyOption(){fails(()->validateFields(new JSONArray().put(field("Облачность","choice","",true,"Ясно;"))));}
    @Test public void requiredValueRejected(){fails(()->entry(field("Объект","text","",true,""),"").validate());}
    @Test public void signedDecimalCommaAccepted(){entry(field("Температура","number","°C",true,""),"-12,5").validate();}
    @Test public void notANumberRejected(){fails(()->entry(field("Высота","number","см",true,""),"abc").validate());}
    @Test public void nonFiniteRejected(){fails(()->entry(field("Высота","number","см",true,""),"NaN").validate());}
    @Test public void infinityRejected(){fails(()->entry(field("Высота","number","см",true,""),"1e999").validate());}
    @Test public void choiceMustMatch(){fails(()->entry(field("Облачность","choice","",true,"Ясно;Пасмурно"),"Снег").validate());}
    @Test public void choiceMatchesTrimmedOption(){entry(field("Облачность","choice","",true,"Ясно; Пасмурно"),"Пасмурно").validate();}
    @Test public void optionalEmptyNumberAccepted(){entry(field("Осадки","number","мм",false,""),"").validate();}
    @Test public void entryNeedsDate(){JSONObject f=field("Объект","text","",true,"");Record e=entry(f,"Клён");e.data.remove("observedAt");fails(e::validate);}
    @Test public void serializationRoundTrip() throws Exception {Record original=card("Вопрос","Ответ","");Record decoded=Record.unpack(new JSONObject(original.packed().toString()));assertEquals(original.id,decoded.id);assertEquals(original.data.toString(),decoded.data.toString());}
    @Test public void snapshotIndependent(){Record t=SeedData.all().get(0);JSONObject copied=copy(t.data);t.data.optJSONArray("fields").optJSONObject(0).remove("label");assertFalse(copied.optJSONArray("fields").optJSONObject(0).optString("label").isEmpty());}
}
