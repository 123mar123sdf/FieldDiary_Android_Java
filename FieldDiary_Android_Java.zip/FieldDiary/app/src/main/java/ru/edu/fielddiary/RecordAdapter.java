package ru.edu.fielddiary;
import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;
public final class RecordAdapter extends BaseAdapter {
    private final Context context;private final List<Record> rows=new ArrayList<>();
    public RecordAdapter(Context c){context=c;}
    public void set(List<Record> records){rows.clear();rows.addAll(records);notifyDataSetChanged();}
    @Override public int getCount(){return rows.size();}
    @Override public Record getItem(int p){return rows.get(p);}
    @Override public long getItemId(int p){return p;}
    @Override public View getView(int p,View view,ViewGroup parent){
        if(view==null)view=LayoutInflater.from(context).inflate(R.layout.item_row,parent,false);
        Record r=getItem(p);((TextView)view.findViewById(R.id.rowTitle)).setText(r.title());
        String detail;
        if(r.kind.equals(ENTRY))detail=Ui.date(r.data.optLong("observedAt"))+" · "+r.data.optString("templateName")+"\n"+r.data.optString("place");
        else if(r.kind.equals(TEMPLATE))detail=r.data.optString("instruction");
        else detail=r.image().isEmpty()?"Вопрос → вспомните → проверьте ответ":"С изображением · Нажмите для повторения";
        TextView sub=view.findViewById(R.id.rowDetail);sub.setMaxLines(3);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);sub.setText(detail);
        return view;
    }
}
