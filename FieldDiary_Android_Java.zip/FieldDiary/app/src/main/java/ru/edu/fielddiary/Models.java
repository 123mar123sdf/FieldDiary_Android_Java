package ru.edu.fielddiary;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

/** Общие структуры и проверки; имена полей являются частью формата резервной копии. */
public final class Models {
    private Models() {}
    public static final String BIO = "bio", GEO = "geo";
    public static final String TEMPLATE = "template", CARD = "card", ENTRY = "entry";
    public static final int MAX_RECORDS = 5000;
    public static String id() { return UUID.randomUUID().toString(); }
    public static String subjectName(String s) { return BIO.equals(s) ? "Биология" : "География"; }
    public static JSONObject object(String s) {
        try { return new JSONObject(s); }
        catch (JSONException e) { throw new IllegalArgumentException("Не удалось прочитать запись", e); }
    }
    public static JSONObject copy(JSONObject o) { return object(o.toString()); }
    public static JSONObject obj(Object... pairs) {
        JSONObject o = new JSONObject();
        try { for (int i=0; i<pairs.length; i+=2) o.put((String)pairs[i], pairs[i+1]); }
        catch (JSONException e) { throw new IllegalArgumentException(e); }
        return o;
    }
    public static String clean(String s) { return s == null ? "" : s.trim(); }
    public static void need(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }
    public static JSONObject field(String label, String type, String unit, boolean required,
                                   String options) {
        return obj("id", id(), "label", label, "type", type, "unit", unit,
                "required", required, "options", options);
    }
    public static void validateFields(JSONArray fields) {
        need(fields != null && fields.length() > 0 && fields.length() <= 30,
                "В теме должно быть от 1 до 30 полей");
        java.util.HashSet<String> ids = new java.util.HashSet<>();
        for (int i=0; i<fields.length(); i++) {
            JSONObject f = fields.optJSONObject(i);
            need(f != null, "Повреждённое описание поля");
            String id=f.optString("id"), type=f.optString("type");
            need(id.matches("[A-Za-z0-9_-]{1,80}") && ids.add(id), "Некорректный идентификатор поля");
            need(!clean(f.optString("label")).isEmpty() && f.optString("label").length()<=120,
                    "Название поля: от 1 до 120 символов");
            need(type.equals("text") || type.equals("number") || type.equals("choice"), "Неизвестный тип поля");
            need(f.optString("unit").length()<=30, "Единица измерения слишком длинная");
            if (type.equals("choice")) {
                String[] options=f.optString("options").split(";",-1);
                need(options.length>=2 && options.length<=30, "Для списка нужно от 2 до 30 вариантов через ;");
                for (String option: options) need(!clean(option).isEmpty() && option.length()<=120,
                        "Варианты списка не должны быть пустыми или длиннее 120 символов");
            }
        }
    }
    public static final class Record {
        public final String id, kind, subject;
        public final JSONObject data;
        public Record(String id, String kind, String subject, JSONObject data) {
            this.id=id; this.kind=kind; this.subject=subject; this.data=data;
        }
        public String title() {
            String s=data.optString(kind.equals(TEMPLATE)?"name":kind.equals(CARD)?"question":"title");
            return s.trim().isEmpty()?"Карточка с изображением":s;
        }
        public String image() { return data.optString("image", ""); }
        public JSONObject packed() { return obj("id",id,"kind",kind,"subject",subject,"data",data); }
        public static Record unpack(JSONObject o) throws JSONException {
            return new Record(o.getString("id"),o.getString("kind"),o.getString("subject"),o.getJSONObject("data"));
        }
        public void validate() {
            need(id.matches("[A-Za-z0-9_-]{1,80}"), "Некорректный идентификатор записи");
            need(BIO.equals(subject)||GEO.equals(subject), "Неизвестный предмет");
            need(TEMPLATE.equals(kind)||CARD.equals(kind)||ENTRY.equals(kind), "Неизвестный тип записи");
            need(data.toString().length()<=200000, "Слишком большая запись");
            need(image().isEmpty()||image().matches("[a-f0-9-]{36}\\.jpg"), "Некорректное имя изображения");
            if (kind.equals(TEMPLATE)) {
                need(!clean(data.optString("name")).isEmpty() && data.optString("name").length()<=120,
                        "Название темы: от 1 до 120 символов");
                need(data.optString("instruction").length()<=10000,"Инструкция слишком длинная");
                validateFields(data.optJSONArray("fields"));
            } else if (kind.equals(CARD)) {
                need(!clean(data.optString("question")).isEmpty()||!image().isEmpty(),"Добавьте вопрос или изображение");
                need(!clean(data.optString("answer")).isEmpty(),"Введите ответ");
                need(data.optString("question").length()<=10000 && data.optString("answer").length()<=10000,
                        "Слишком длинный текст карточки");
            } else {
                need(!clean(data.optString("title")).isEmpty() && data.optString("title").length()<=10000,
                        "Введите название записи");
                need(data.optLong("observedAt",0)>0,"Укажите дату наблюдения");
                JSONArray fields=data.optJSONArray("fields");
                validateFields(fields);
                JSONObject values=data.optJSONObject("values");
                need(values!=null,"Нет значений полей");
                for(int i=0;i<fields.length();i++) {
                    JSONObject f=fields.optJSONObject(i);
                    String v=clean(values.optString(f.optString("id")));
                    need(v.length()<=10000,"Слишком длинное значение поля");
                    need(!f.optBoolean("required")||!v.isEmpty(),"Заполните поле: "+f.optString("label"));
                    if (!v.isEmpty() && f.optString("type").equals("number")) {
                        try { double d=Double.parseDouble(v.replace(',','.'));
                            need(!Double.isNaN(d)&&!Double.isInfinite(d),"Введите конечное число"); }
                        catch(NumberFormatException e) { throw new IllegalArgumentException("Введите число: "+f.optString("label")); }
                    }
                    if (!v.isEmpty() && f.optString("type").equals("choice")) {
                        boolean found=false;
                        for(String opt:f.optString("options").split(";")) if (v.equals(opt.trim())) found=true;
                        need(found,"Выберите вариант: "+f.optString("label"));
                    }
                }
            }
        }
    }
}
