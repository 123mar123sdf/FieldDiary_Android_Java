package ru.edu.fielddiary;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

/** Все вызовы выполняются через единый фоновый исполнитель DiaryApp. */
public final class Store extends SQLiteOpenHelper {
    public Store(Context context) { super(context,"field_diary.db",null,1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE records (id TEXT PRIMARY KEY, kind TEXT NOT NULL, subject TEXT NOT NULL, payload TEXT NOT NULL, updated INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX subject_kind ON records(subject,kind)");
        for(Record r:SeedData.all()) write(db,r,SQLiteDatabase.CONFLICT_ABORT);
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        throw new IllegalStateException("Для этой версии не предусмотрено изменение структуры базы");
    }
    private long write(SQLiteDatabase db, Record r,int conflict) {
        ContentValues v=new ContentValues(); v.put("id",r.id);v.put("kind",r.kind);v.put("subject",r.subject);
        v.put("payload",r.data.toString());v.put("updated",System.currentTimeMillis());
        return db.insertWithOnConflict("records",null,v,conflict);
    }
    public Record get(String id) {
        try(Cursor c=getReadableDatabase().query("records",null,"id=?",new String[]{id},null,null,null)) {
            return c.moveToFirst()?read(c):null;
        }
    }
    private Record read(Cursor c) {
        return new Record(c.getString(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("kind")),
                c.getString(c.getColumnIndexOrThrow("subject")),object(c.getString(c.getColumnIndexOrThrow("payload"))));
    }
    public List<Record> list(String subject,String kind) {
        List<Record> out=new ArrayList<>();
        String where=subject==null?null:"subject=? AND kind=?";
        String[] args=subject==null?null:new String[]{subject,kind};
        try(Cursor c=getReadableDatabase().query("records",null,where,args,null,null,"updated DESC, id ASC")) {
            while(c.moveToNext()) out.add(read(c));
        }
        if(ENTRY.equals(kind)) out.sort((a,b)->Long.compare(b.data.optLong("observedAt"),a.data.optLong("observedAt")));
        return out;
    }
    public void save(Record r) {
        r.validate();
        SQLiteDatabase db=getWritableDatabase();
        if(get(r.id)==null) need(android.database.DatabaseUtils.queryNumEntries(db,"records")<MAX_RECORDS,"Достигнут предел: 5000 записей. Сделайте копию и удалите ненужные записи.");
        need(write(db,r,SQLiteDatabase.CONFLICT_REPLACE)!=-1,"Не удалось сохранить запись");
    }
    public void delete(String id) { getWritableDatabase().delete("records","id=?",new String[]{id}); }
    public int addImported(List<Record> records,boolean updateMaterials) {
        SQLiteDatabase db=getWritableDatabase();int count=0;
        db.beginTransaction();
        try {
            int total=(int)android.database.DatabaseUtils.queryNumEntries(db,"records");
            for(Record r:records) {
                r.validate();
                Record existing=get(r.id);
                boolean replace=existing!=null&&updateMaterials&&!r.kind.equals(ENTRY);
                if(existing!=null&&!replace)continue;
                if(replace)need(existing.kind.equals(r.kind)&&existing.subject.equals(r.subject),"Конфликт типов материалов в архиве");
                if(!replace)need(total<MAX_RECORDS,"После импорта будет больше 5000 записей");
                need(write(db,r,replace?SQLiteDatabase.CONFLICT_REPLACE:SQLiteDatabase.CONFLICT_ABORT)!=-1,"Ошибка импорта");
                count++;if(!replace)total++;
            }
            db.setTransactionSuccessful();return count;
        } finally { db.endTransaction(); }
    }
}
