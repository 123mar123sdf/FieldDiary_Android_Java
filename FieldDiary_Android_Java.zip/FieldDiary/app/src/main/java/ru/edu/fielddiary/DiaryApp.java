package ru.edu.fielddiary;
import android.app.Application;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public final class DiaryApp extends Application {
    public final ExecutorService io=Executors.newSingleThreadExecutor();
    public Store store;
    @Override public void onCreate() { super.onCreate();store=new Store(this); }
}
