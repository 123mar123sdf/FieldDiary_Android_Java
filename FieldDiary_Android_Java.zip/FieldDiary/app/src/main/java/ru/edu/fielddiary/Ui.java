package ru.edu.fielddiary;
import android.content.Context;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

public final class Ui {
    private Ui() {}
    public static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    public static String date(long t){return new SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("ru")).format(new Date(t));}
    public static Button button(Context c,String label,Runnable action){
        Button b=new Button(c,null,0,R.style.Button_Secondary);b.setText(label);b.setOnClickListener(v->action.run());return b;
    }
    public static TextView label(Context c,String title){
        TextView t=new TextView(c,null,0,R.style.Text_Label);t.setText(title);return t;
    }
    public static EditText input(Context c,String hint,String text,int max){
        EditText e=new EditText(c);e.setHint(hint);e.setText(text);
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});return e;
    }
    public static ArrayAdapter<String> spinnerAdapter(Context c,List<String> names){
        ArrayAdapter<String> a=new ArrayAdapter<>(c,android.R.layout.simple_spinner_item,names);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);return a;
    }
    /** Поля записи создаются из схемы темы; при сохранении схема копируется в запись. */
    public static final class Form {
        private final JSONArray fields;
        private final LinkedHashMap<String,View> controls=new LinkedHashMap<>();
        public Form(Context c,LinearLayout container,JSONArray fields,JSONObject values) {
            this.fields=fields;container.removeAllViews();
            for(int i=0;i<fields.length();i++){
                JSONObject f=fields.optJSONObject(i);String id=f.optString("id");
                String unit=f.optString("unit"), type=f.optString("type");
                container.addView(label(c,f.optString("label")+(unit.isEmpty()?"":" ("+unit+")")+(f.optBoolean("required")?" *":"")));
                if(type.equals("choice")) {
                    Spinner s=new Spinner(c);List<String> opts=new ArrayList<>();opts.add("— Не выбрано —");
                    for(String v:f.optString("options").split(";")) opts.add(v.trim());
                    s.setAdapter(spinnerAdapter(c,opts));int index=opts.indexOf(values.optString(id));s.setSelection(Math.max(0,index));
                    container.addView(s,new LinearLayout.LayoutParams(-1,dp(c,52)));controls.put(id,s);
                } else {
                    EditText e=input(c,"Введите значение",values.optString(id),10000);
                    if(type.equals("number")) e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
                    e.setId(View.generateViewId());container.addView(e);controls.put(id,e);
                }
            }
        }
        public JSONObject values(){
            JSONObject out=new JSONObject();
            try {
                for(Map.Entry<String,View> item:controls.entrySet()){
                    View v=item.getValue();String value;
                    if(v instanceof Spinner){Spinner s=(Spinner)v;value=s.getSelectedItemPosition()==0?"":s.getSelectedItem().toString();}
                    else value=((EditText)v).getText().toString().trim();
                    out.put(item.getKey(),value);
                }
            }catch(org.json.JSONException e){throw new IllegalArgumentException(e);}
            return out;
        }
        public void validate(){
            JSONObject d=obj("title","Проверка","observedAt",System.currentTimeMillis(),"fields",fields,"values",values());
            new Record("validation",ENTRY,BIO,d).validate();
        }
    }
    public static String entryText(Record r){
        JSONObject d=r.data;StringBuilder s=new StringBuilder(date(d.optLong("observedAt")));
        for(String key:new String[]{"templateName","observer","place","instruction"}){
            String v=d.optString(key);if(!v.isEmpty())s.append("\n\n").append(key.equals("instruction")?"Задание: ":key.equals("observer")?"Наблюдатель: ":key.equals("place")?"Место: ":"Тема: ").append(v);
        }
        JSONArray fields=d.optJSONArray("fields");JSONObject values=d.optJSONObject("values");
        if(fields!=null&&values!=null)for(int i=0;i<fields.length();i++){
            JSONObject f=fields.optJSONObject(i);String v=values.optString(f.optString("id"));
            s.append("\n\n").append(f.optString("label")).append(": ").append(v.isEmpty()?"—":v);
            if(!v.isEmpty()&&!f.optString("unit").isEmpty())s.append(" ").append(f.optString("unit"));
        }
        if(!d.optString("notes").isEmpty())s.append("\n\nВывод / примечания: ").append(d.optString("notes"));
        return s.toString();
    }
}
