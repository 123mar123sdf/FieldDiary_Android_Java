package ru.edu.fielddiary;
import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;
import androidx.core.content.FileProvider;
import java.io.File;

/** Общий модуль камеры и выбора изображения для двух редакторов. */
public abstract class PhotoActivity extends BaseActivity {
    private static final int PICK=401,CAMERA=402;
    protected String imageName="";
    protected boolean restored=false;
    private String capturePath="";
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        if(state!=null){restored=true;imageName=state.getString("photoName","");capturePath=state.getString("capturePath","");}
    }
    protected void bindPhoto(){
        findViewById(R.id.choosePhoto).setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Добавить изображение")
            .setItems(new String[]{"Камера","Галерея / фотографии","Проводник / файлы"},(d,i)->{
                if(i==0)camera();else pick(i==1);
            }).show());
        findViewById(R.id.removePhoto).setOnClickListener(v->{imageName="";refreshPhoto();});refreshPhoto();
    }
    protected void refreshPhoto(){ImageStore.show(this,(ImageView)findViewById(R.id.photoPreview),imageName);}
    private void pick(boolean gallery){
        Intent i=new Intent(gallery?Intent.ACTION_GET_CONTENT:Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivityForResult(Intent.createChooser(i,gallery?"Выберите фотографию":"Выберите файл изображения"),PICK);}
        catch(ActivityNotFoundException e){error(new Exception("На устройстве нет приложения для выбора изображений"));}
    }
    private void camera(){
        try{
            File dir=new File(getCacheDir(),"camera");if(!dir.isDirectory()&&!dir.mkdirs())throw new java.io.IOException("Нет папки для фото");
            File file=File.createTempFile("shot_",".jpg",dir);capturePath=file.getAbsolutePath();
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",file);
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,uri);
            i.setClipData(ClipData.newRawUri("Фото наблюдения",uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(i,CAMERA);
        }catch(Exception e){cleanupCapture();error(new Exception("Не удалось открыть камеру. Проверьте, установлено ли приложение камеры.",e));}
    }
    private void cleanupCapture(){if(!capturePath.isEmpty()){new File(capturePath).delete();capturePath="";}}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=PICK&&request!=CAMERA)return;
        if(result!=RESULT_OK){if(request==CAMERA)cleanupCapture();return;}
        final File capture=request==CAMERA&&!capturePath.isEmpty()?new File(capturePath):null;
        Uri uri=request==CAMERA?(capture==null?null:Uri.fromFile(capture)):(data==null?null:data.getData());
        if(uri==null){cleanupCapture();error(new Exception("Изображение не выбрано"));return;}
        importWhenReady(uri,capture);
    }
    private void importWhenReady(Uri uri,File capture){
        if(isDestroyed()||isFinishing())return;
        if(busy){new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->importWhenReady(uri,capture),50);return;}
        work(()->{
            try{return ImageStore.importImage(this,uri);}
            finally{if(capture!=null)capture.delete();}
        },name->{capturePath="";imageName=name;refreshPhoto();});
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("photoName",imageName);out.putString("capturePath",capturePath);super.onSaveInstanceState(out);
    }
}
