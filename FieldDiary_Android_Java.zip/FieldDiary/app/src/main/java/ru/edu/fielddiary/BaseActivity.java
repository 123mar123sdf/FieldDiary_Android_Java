package ru.edu.fielddiary;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import java.util.concurrent.Callable;

public abstract class BaseActivity extends Activity {
    protected DiaryApp app;
    protected boolean busy=false;
    public interface Done<T> { void accept(T value); }
    @Override protected void onCreate(Bundle state) { super.onCreate(state);app=(DiaryApp)getApplication(); }
    protected void setup(int layout,String title) {
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        setContentView(layout);
        View root=findViewById(R.id.root);
        int l=root.getPaddingLeft(),t=root.getPaddingTop(),r=root.getPaddingRight(),b=root.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(root,(v,wi)->{
            Insets in=wi.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout()|WindowInsetsCompat.Type.ime());
            v.setPadding(l+in.left,t+in.top,r+in.right,b+in.bottom); return wi;
        });
        ViewCompat.requestApplyInsets(root);
        ((TextView)findViewById(R.id.screenTitle)).setText(title);
        findViewById(R.id.back).setOnClickListener(v->finish());
    }
    protected String subject() {
        String s=getIntent().getStringExtra("subject");return Models.GEO.equals(s)?Models.GEO:Models.BIO;
    }
    protected String recordId() { String s=getIntent().getStringExtra("id");return s==null?"":s; }
    protected String value(int id) { return ((TextView)findViewById(id)).getText().toString().trim(); }
    protected void text(int id,String text) { ((TextView)findViewById(id)).setText(text); }
    protected void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    protected void error(Exception e) {
        if(isFinishing()||isDestroyed())return;
        String msg=e.getMessage();
        new AlertDialog.Builder(this).setTitle("Не удалось выполнить действие")
            .setMessage(msg==null?"Проверьте данные и доступное место в памяти.":msg).setPositiveButton("Понятно",null).show();
    }
    private void enabled(View view,boolean enabled) {
        view.setEnabled(enabled);
        if(view instanceof ViewGroup) for(int i=0;i<((ViewGroup)view).getChildCount();i++) enabled(((ViewGroup)view).getChildAt(i),enabled);
    }
    protected void setBusy(boolean b) {
        busy=b;enabled(findViewById(R.id.root),!b);
        findViewById(R.id.progress).setVisibility(b?View.VISIBLE:View.GONE);
    }
    protected <T> void work(Callable<T> task,Done<T> done) {
        if(busy)return; setBusy(true);
        app.io.execute(()->{
            try {
                T result=task.call();
                runOnUiThread(()->{if(!isDestroyed()&&!isFinishing()){
                    setBusy(false);try { done.accept(result); } catch(Exception e){error(e);}
                }});
            } catch(Exception e) {
                runOnUiThread(()->{if(!isDestroyed()&&!isFinishing()){setBusy(false);error(e);}});
            }
        });
    }
    protected void confirmDelete(String id,String note,Done<Boolean> after) {
        new AlertDialog.Builder(this).setTitle("Удалить?").setMessage(note)
            .setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->
                work(()->{app.store.delete(id);return true;},after)).show();
    }
    @Override public void onBackPressed() { if(!busy)super.onBackPressed(); }
}
