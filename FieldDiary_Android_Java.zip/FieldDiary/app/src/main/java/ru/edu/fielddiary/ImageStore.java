package ru.edu.fielddiary;
import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.widget.ImageView;
import java.io.*;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

public final class ImageStore {
    private ImageStore() {}
    public static File dir(Context c) throws IOException {
        File d=new File(c.getFilesDir(),"images");if(!d.isDirectory()&&!d.mkdirs())throw new IOException("Не удалось создать папку изображений");return d;
    }
    public static File file(Context c,String name) throws IOException {
        need(name.matches("[a-f0-9-]{36}\\.jpg"),"Некорректное имя изображения");return new File(dir(c),name);
    }
    private static InputStream open(Context c,Uri uri) throws IOException {
        InputStream in=c.getContentResolver().openInputStream(uri);if(in==null)throw new IOException("Нет доступа к изображению");return in;
    }
    private static Bitmap decode(Context c,Uri uri,int edge) throws IOException {
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
        try(InputStream in=open(c,uri)){BitmapFactory.decodeStream(in,null,o);}
        if(o.outWidth<=0||o.outHeight<=0||o.outWidth>50000||o.outHeight>50000)throw new IOException("Выберите поддерживаемое изображение JPEG, PNG, WebP или HEIF");
        int width=o.outWidth,height=o.outHeight;o.inJustDecodeBounds=false;o.inSampleSize=1;
        while(Math.max(width,height)/o.inSampleSize>edge*2)o.inSampleSize*=2;
        o.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap b;
        try(InputStream in=open(c,uri)){b=BitmapFactory.decodeStream(in,null,o);}
        if(b==null)throw new IOException("Не удалось декодировать изображение");
        if(Math.max(b.getWidth(),b.getHeight())>edge){
            float k=(float)edge/Math.max(b.getWidth(),b.getHeight());
            Bitmap small=Bitmap.createScaledBitmap(b,Math.max(1,Math.round(b.getWidth()*k)),Math.max(1,Math.round(b.getHeight()*k)),true);
            if(small!=b)b.recycle();b=small;
        }
        return b;
    }
    public static String importImage(Context c,Uri uri) throws IOException {
        Bitmap b=decode(c,uri,1600);
        int orientation=1;
        try(InputStream in=open(c,uri)) {
            orientation=new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);
        } catch(IOException ignored) { /* Некоторые форматы не содержат EXIF. */ }
        Matrix m=new Matrix();
        switch(orientation){
            case 2:m.setScale(-1,1);break;
            case 3:m.setRotate(180);break;
            case 4:m.setScale(1,-1);break;
            case 5:m.setRotate(90);m.postScale(-1,1);break;
            case 6:m.setRotate(90);break;
            case 7:m.setRotate(-90);m.postScale(-1,1);break;
            case 8:m.setRotate(-90);break;
            default:break;
        }
        Bitmap turned=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);
        if(turned!=b)b.recycle();b=turned;
        String name=id()+".jpg";File output=file(c,name);
        try {
            try(OutputStream out=new FileOutputStream(output)) {
                if(!b.compress(Bitmap.CompressFormat.JPEG,85,out))throw new IOException("Не удалось сохранить фото");
            }
        } catch(IOException e){output.delete();throw e;} finally {b.recycle();}
        return name;
    }
    public static void show(Context c,ImageView image,String name) {
        image.setTag(name);image.setImageDrawable(null);
        image.setVisibility(name.isEmpty()?android.view.View.GONE:android.view.View.VISIBLE);
        if(name.isEmpty())return;
        Context context=c.getApplicationContext();DiaryApp app=(DiaryApp)context;
        java.lang.ref.WeakReference<ImageView> ref=new java.lang.ref.WeakReference<>(image);
        app.io.execute(()->{
            Bitmap bitmap=null;
            try{bitmap=decode(context,Uri.fromFile(file(context,name)),1000);}catch(Exception ignored){}
            Bitmap result=bitmap;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(()->{
                ImageView v=ref.get();
                if(v!=null&&name.equals(v.getTag())&&(!(v.getContext() instanceof Activity)||!((Activity)v.getContext()).isDestroyed())) {
                    if(result!=null)v.setImageBitmap(result);else {v.setImageResource(R.drawable.ic_camera);v.setContentDescription("Изображение недоступно");}
                } else if(result!=null)result.recycle();
            });
        });
    }
    public static void prune(Context c,Store store) throws IOException {
        Set<String> used=new HashSet<>();for(Record r:store.list(null,null))used.add(r.image());
        File[] files=dir(c).listFiles();long cutoff=System.currentTimeMillis()-7L*24*60*60*1000;
        if(files!=null)for(File f:files)if(!used.contains(f.getName())&&f.lastModified()<cutoff)f.delete();
        File camera=new File(c.getCacheDir(),"camera");File[] temp=camera.listFiles();
        if(temp!=null)for(File f:temp)if(f.lastModified()<cutoff)f.delete();
    }
}
