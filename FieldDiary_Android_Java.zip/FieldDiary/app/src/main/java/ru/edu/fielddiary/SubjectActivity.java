package ru.edu.fielddiary;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.*;
import android.view.View;
import android.widget.*;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

public final class SubjectActivity extends BaseActivity {
    private String kind=ENTRY;private RecordAdapter adapter;
    private List<Record> all=new ArrayList<>();private long generation=0;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);if(state!=null)kind=state.getString("kind",ENTRY);
        setup(R.layout.activity_subject,subjectName(subject()));adapter=new RecordAdapter(this);
        ListView list=findViewById(R.id.list);list.setAdapter(adapter);list.setEmptyView(findViewById(R.id.empty));
        findViewById(R.id.journal).setOnClickListener(v->change(ENTRY));
        findViewById(R.id.cards).setOnClickListener(v->change(CARD));
        findViewById(R.id.templates).setOnClickListener(v->change(TEMPLATE));
        findViewById(R.id.add).setOnClickListener(v->edit(null));
        findViewById(R.id.study).setOnClickListener(v->study(null));
        list.setOnItemClickListener((p,v,pos,id)->{Record r=adapter.getItem(pos);if(r.kind.equals(ENTRY))showEntry(r);else if(r.kind.equals(CARD))study(r);else edit(r);});
        list.setOnItemLongClickListener((p,v,pos,id)->{
            Record r=adapter.getItem(pos);new AlertDialog.Builder(this).setTitle(r.title())
                .setItems(new String[]{"Изменить","Удалить"},(d,n)->{
                    if(n==0)edit(r);else confirmDelete(r.id,r.kind.equals(TEMPLATE)?"Тема будет удалена. Ранее сделанные записи останутся со своими полями.":"Запись будет удалена без возможности отмены. Рекомендуется предварительно сделать резервную копию.",ok->reload());
                }).show();return true;
        });
        ((EditText)findViewById(R.id.search)).addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){filter();}
            public void afterTextChanged(Editable e){}
        });
        updateTabs();
    }
    @Override protected void onResume(){super.onResume();reload();}
    private void change(String next){if(busy)return;kind=next;updateTabs();reload();}
    private void updateTabs(){
        findViewById(R.id.study).setVisibility(kind.equals(CARD)?View.VISIBLE:View.GONE);
        text(R.id.sectionHint,kind.equals(TEMPLATE)?"Учитель: создавайте темы, задания и свои поля формы. Нажмите тему для настройки.":kind.equals(CARD)?"Нажмите карточку для повторения. Удерживайте, чтобы изменить или удалить.":"Нажмите запись для просмотра. Удерживайте, чтобы изменить или удалить.");
        text(R.id.add,kind.equals(TEMPLATE)?"Добавить тему":kind.equals(CARD)?"Добавить карточку":"Новое наблюдение");
        for(int id:new int[]{R.id.journal,R.id.cards,R.id.templates})((TextView)findViewById(id)).setTypeface(null,android.graphics.Typeface.NORMAL);
        ((TextView)findViewById(kind.equals(ENTRY)?R.id.journal:kind.equals(CARD)?R.id.cards:R.id.templates)).setTypeface(null,android.graphics.Typeface.BOLD);
    }
    private void reload(){
        if(busy)return;long token=++generation;String requestedKind=kind;
        work(()->app.store.list(subject(),requestedKind),rows->{if(token==generation){all=rows;filter();}});
    }
    private void filter(){
        String query=value(R.id.search).toLowerCase(new Locale("ru"));List<Record> rows=new ArrayList<>();
        for(Record r:all)if(query.isEmpty()||r.title().toLowerCase(new Locale("ru")).contains(query)||
                (r.kind.equals(ENTRY)?Ui.entryText(r):r.kind.equals(TEMPLATE)?r.data.optString("instruction"):r.data.optString("answer")).toLowerCase(new Locale("ru")).contains(query))rows.add(r);
        adapter.set(rows);
    }
    private void edit(Record r){
        Class<?> cls=kind.equals(ENTRY)?EntryEditorActivity.class:kind.equals(CARD)?CardEditorActivity.class:TemplateEditorActivity.class;
        Intent i=new Intent(this,cls).putExtra("subject",subject());if(r!=null)i.putExtra("id",r.id);startActivity(i);
    }
    private void study(Record first){
        Intent i=new Intent(this,StudyActivity.class).putExtra("subject",subject());
        ArrayList<String> ids=new ArrayList<>();for(int p=0;p<adapter.getCount();p++)ids.add(adapter.getItem(p).id);
        if(first!=null){ids.remove(first.id);ids.add(0,first.id);}
        if(ids.isEmpty()){toast("Сначала добавьте карточку");return;}
        i.putStringArrayListExtra("cardIds",ids);startActivity(i);
    }
    private void showEntry(Record r){
        ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);int pad=Ui.dp(this,20);body.setPadding(pad,pad,pad,pad);scroll.addView(body);
        TextView t=new TextView(this);t.setText(Ui.entryText(r));t.setTextIsSelectable(true);body.addView(t);
        ImageView photo=new ImageView(this);photo.setContentDescription("Фото наблюдения");photo.setScaleType(ImageView.ScaleType.FIT_CENTER);body.addView(photo,new LinearLayout.LayoutParams(-1,Ui.dp(this,240)));ImageStore.show(this,photo,r.image());
        new AlertDialog.Builder(this).setTitle(r.title()).setView(scroll).setPositiveButton("Закрыть",null)
            .setNeutralButton("Изменить",(d,w)->edit(r)).show();
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putString("kind",kind);super.onSaveInstanceState(out);}
}
