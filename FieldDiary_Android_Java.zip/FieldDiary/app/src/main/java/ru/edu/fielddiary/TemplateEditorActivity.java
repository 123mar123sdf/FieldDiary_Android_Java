package ru.edu.fielddiary;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

/** Конструктор формы для учителя. Строки полей имеют стабильные UUID. */
public final class TemplateEditorActivity extends BaseActivity {
    private final List<FieldRow> rows=new ArrayList<>();private String id;private boolean ready=false;
    private JSONObject draft;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);id=state!=null?state.getString("editingId"):recordId();if(id.isEmpty())id=Models.id();
        if(state!=null&&state.containsKey("draft"))draft=object(state.getString("draft"));
        setup(R.layout.activity_template_editor,recordId().isEmpty()?"Новая тема":"Настройка темы");
        findViewById(R.id.delete).setVisibility(recordId().isEmpty()?View.GONE:View.VISIBLE);
        findViewById(R.id.delete).setOnClickListener(v->confirmDelete(id,"Удалить тему? Ранее созданные наблюдения сохранятся со своими полями.",ok->finish()));
        findViewById(R.id.addField).setOnClickListener(v->{if(rows.size()>=30)toast("В одной теме можно добавить не больше 30 полей");else addRow(field("","text","",false,""));});
        findViewById(R.id.save).setOnClickListener(v->save());
        if(draft!=null)fill(draft);
        else if(recordId().isEmpty()){
            JSONArray f=new JSONArray().put(field("Объект наблюдения","text","",true,""));
            fill(obj("name","","instruction","","fields",f));
        }else work(()->app.store.get(recordId()),r->{if(r==null){toast("Тема уже удалена");finish();return;}fill(r.data);});
    }
    private void fill(JSONObject d){
        text(R.id.templateName,d.optString("name"));text(R.id.instruction,d.optString("instruction"));
        JSONArray fields=d.optJSONArray("fields");if(fields!=null)for(int i=0;i<fields.length();i++)addRow(fields.optJSONObject(i));ready=true;
    }
    private void addRow(JSONObject f){FieldRow row=new FieldRow(f);rows.add(row);((LinearLayout)findViewById(R.id.fieldList)).addView(row.box);}
    private JSONObject collect(){
        JSONArray fields=new JSONArray();for(FieldRow row:rows)fields.put(row.data());
        return obj("name",value(R.id.templateName),"instruction",value(R.id.instruction),"fields",fields);
    }
    private void save(){
        if(!ready)return;
        try{Record r=new Record(id,TEMPLATE,subject(),collect());r.validate();
            work(()->{app.store.save(r);return true;},ok->{toast("Тема сохранена. Её можно выбрать при создании наблюдения.");finish();});}
        catch(Exception e){error(e);}
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("editingId",id);if(ready)out.putString("draft",collect().toString());else if(draft!=null)out.putString("draft",draft.toString());super.onSaveInstanceState(out);
    }
    private final class FieldRow {
        final String fieldId;final LinearLayout box;
        final EditText label,unit,options;final CheckBox required;final Spinner type;
        final String[] types={"text","number","choice"};
        FieldRow(JSONObject f){
            fieldId=f.optString("id",Models.id());box=new LinearLayout(TemplateEditorActivity.this);box.setOrientation(LinearLayout.VERTICAL);
            box.setBackgroundResource(R.drawable.bg_card);int p=Ui.dp(TemplateEditorActivity.this,14);box.setPadding(p,p,p,p);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=p;box.setLayoutParams(lp);
            box.addView(Ui.label(TemplateEditorActivity.this,"Название поля"));
            label=Ui.input(TemplateEditorActivity.this,"Например: высота растения",f.optString("label"),120);box.addView(label);
            box.addView(Ui.label(TemplateEditorActivity.this,"Тип значения"));type=new Spinner(TemplateEditorActivity.this);
            type.setAdapter(Ui.spinnerAdapter(TemplateEditorActivity.this,Arrays.asList("Текст","Число","Список вариантов")));int index=Arrays.asList(types).indexOf(f.optString("type"));type.setSelection(Math.max(index,0));box.addView(type,new LinearLayout.LayoutParams(-1,Ui.dp(TemplateEditorActivity.this,52)));
            unit=Ui.input(TemplateEditorActivity.this,"Единица измерения, например см (необязательно)",f.optString("unit"),30);box.addView(unit);
            options=Ui.input(TemplateEditorActivity.this,"Варианты через ; например: Ясно;Пасмурно",f.optString("options"),4000);box.addView(options);
            required=new CheckBox(TemplateEditorActivity.this);required.setText("Обязательное поле");required.setChecked(f.optBoolean("required"));box.addView(required);
            box.addView(Ui.button(TemplateEditorActivity.this,"Удалить это поле",()->new AlertDialog.Builder(TemplateEditorActivity.this).setTitle("Удалить поле?").setMessage("Поле будет удалено из новых форм после сохранения темы. Старые наблюдения не изменятся.").setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->{rows.remove(this);((LinearLayout)findViewById(R.id.fieldList)).removeView(box);}).show()));
            type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                public void onNothingSelected(android.widget.AdapterView<?> p){}
                public void onItemSelected(android.widget.AdapterView<?> parent,View v,int pos,long id){options.setVisibility(pos==2?View.VISIBLE:View.GONE);}
            });
            options.setVisibility(type.getSelectedItemPosition()==2?View.VISIBLE:View.GONE);
        }
        JSONObject data(){return obj("id",fieldId,"label",label.getText().toString().trim(),"type",types[type.getSelectedItemPosition()],"unit",unit.getText().toString().trim(),"options",options.getText().toString().trim(),"required",required.isChecked());}
    }
}
