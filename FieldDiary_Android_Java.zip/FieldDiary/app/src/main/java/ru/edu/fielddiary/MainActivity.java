package ru.edu.fielddiary;
import android.app.AlertDialog;
import android.content.*;
import android.os.Bundle;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends BaseActivity {
    private static final int EXPORT_MATERIALS=501,EXPORT_ALL=502,IMPORT=503;
    private boolean updateMaterials=false;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);if(state!=null)updateMaterials=state.getBoolean("updateMaterials");setup(R.layout.activity_main,"Дневник наблюдений");
        findViewById(R.id.back).setVisibility(View.GONE);
        findViewById(R.id.biology).setOnClickListener(v->open(Models.BIO));
        findViewById(R.id.geography).setOnClickListener(v->open(Models.GEO));
        findViewById(R.id.exportMaterials).setOnClickListener(v->exportFile(true));
        findViewById(R.id.exportAll).setOnClickListener(v->exportFile(false));
        findViewById(R.id.importData).setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle("Как импортировать файл?")
            .setItems(new String[]{"Добавить новые, совпадающие пропустить","Добавить новые и обновить темы / карточки"},(dialog,mode)->{
                updateMaterials=mode==1;
                new AlertDialog.Builder(this).setTitle("Подтверждение импорта")
                    .setMessage(updateMaterials?"Совпавшие по идентификаторам темы и карточки будут заменены содержимым архива. Существующие наблюдения не изменятся. Сначала сделайте резервную копию. Открывайте файлы только от доверенного отправителя.":"Будут добавлены только записи с новыми идентификаторами. Совпавшие записи останутся без изменений. Открывайте файлы только от доверенного отправителя.")
                    .setNegativeButton(R.string.cancel,null).setPositiveButton("Выбрать ZIP-файл",(d,w)->{
                        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
                        try{startActivityForResult(i,IMPORT);}catch(ActivityNotFoundException e){error(e);}
                    }).show();
            }).show());
        work(()->{app.store.getReadableDatabase();ImageStore.prune(this,app.store);return true;},ok->{});
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("updateMaterials",updateMaterials);super.onSaveInstanceState(out);}
    private void open(String subject){startActivity(new Intent(this,SubjectActivity.class).putExtra("subject",subject));}
    private void exportFile(boolean materials){
        String suffix=new SimpleDateFormat("yyyy-MM-dd_HH-mm",Locale.US).format(new Date());
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE,(materials?"materials_":"diary_backup_")+suffix+".zip");
        try{startActivityForResult(i,materials?EXPORT_MATERIALS:EXPORT_ALL);}catch(ActivityNotFoundException e){error(e);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        android.net.Uri uri=data.getData();
        if(request==IMPORT)work(()->Backup.importData(this,app.store,uri,updateMaterials),message->new AlertDialog.Builder(this).setTitle("Импорт завершён").setMessage(message).setPositiveButton("Готово",null).show());
        else if(request==EXPORT_MATERIALS||request==EXPORT_ALL)work(()->Backup.exportData(this,app.store,uri,request==EXPORT_MATERIALS),n->toast("Файл сохранён. Записей: "+n));
    }
}
