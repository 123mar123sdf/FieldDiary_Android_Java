package ru.edu.fielddiary;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

/** Самопроверка: ответ скрыт до переворота. «Повторить» возвращает карточку в конец очереди. */
public final class StudyActivity extends BaseActivity {
    private final Map<String,Record> cards=new LinkedHashMap<>();
    private ArrayList<String> initial=new ArrayList<>();private ArrayDeque<String> queue=new ArrayDeque<>();
    private int remembered=0,attempts=0;private boolean flipped=false,ready=false;
    private Bundle restoredState;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);restoredState=state;setup(R.layout.activity_study,"Повторение · "+subjectName(subject()));
        findViewById(R.id.flip).setOnClickListener(v->{flipped=!flipped;render();});
        findViewById(R.id.flashSurface).setOnClickListener(v->{if(ready&&!queue.isEmpty()){flipped=!flipped;render();}});
        findViewById(R.id.remember).setOnClickListener(v->grade(true));findViewById(R.id.again).setOnClickListener(v->grade(false));
        findViewById(R.id.restart).setOnClickListener(v->{queue=new ArrayDeque<>(initial);remembered=0;attempts=0;flipped=false;render();});
        ArrayList<String> requested=getIntent().getStringArrayListExtra("cardIds");
        work(()->app.store.list(subject(),CARD),records->{
            for(Record r:records)cards.put(r.id,r);
            if(requested!=null)for(String id:requested)if(cards.containsKey(id)&&!initial.contains(id))initial.add(id);
            if(requested==null)initial.addAll(cards.keySet());
            ArrayList<String> saved=restoredState==null?null:restoredState.getStringArrayList("queue");
            for(String id:saved==null?initial:saved)if(cards.containsKey(id))queue.add(id);
            if(restoredState!=null){flipped=restoredState.getBoolean("flipped");remembered=restoredState.getInt("remembered");attempts=restoredState.getInt("attempts");}
            ready=true;render();
        });
    }
    private void grade(boolean remember){
        if(!ready||!flipped||queue.isEmpty())return;
        String id=queue.removeFirst();attempts++;if(remember)remembered++;else queue.addLast(id);flipped=false;render();
    }
    private void render(){
        boolean empty=queue.isEmpty();findViewById(R.id.flip).setVisibility(empty?View.GONE:View.VISIBLE);
        findViewById(R.id.remember).setVisibility(!empty&&flipped?View.VISIBLE:View.GONE);
        findViewById(R.id.again).setVisibility(!empty&&flipped?View.VISIBLE:View.GONE);
        findViewById(R.id.restart).setVisibility(empty&&!initial.isEmpty()?View.VISIBLE:View.GONE);
        if(empty){
            text(R.id.counter,"Карточек: "+initial.size()+" · Проверок: "+attempts);
            text(R.id.sideLabel,initial.isEmpty()?"Пока нет карточек":"Сессия завершена");
            text(R.id.flashText,initial.isEmpty()?"Добавьте карточки в разделе предмета.":"Вы отметили как запомненные: "+remembered+".\nМожно начать заново.");
            ImageStore.show(this,(ImageView)findViewById(R.id.studyImage),"");return;
        }
        Record r=cards.get(queue.peekFirst());text(R.id.counter,"Осталось: "+queue.size()+" · Помню: "+remembered+" · Проверок: "+attempts);
        text(R.id.sideLabel,flipped?"Ответ":"Вопрос — сначала попробуйте вспомнить");
        text(R.id.flashText,flipped?r.data.optString("answer"):r.data.optString("question").isEmpty()?"Что изображено?":r.data.optString("question"));
        text(R.id.flip,flipped?"Снова вопрос":"Показать ответ");
        ImageStore.show(this,(ImageView)findViewById(R.id.studyImage),flipped?"":r.image());
    }
    @Override protected void onSaveInstanceState(Bundle out){
        if(ready){out.putStringArrayList("queue",new ArrayList<>(queue));out.putBoolean("flipped",flipped);out.putInt("remembered",remembered);out.putInt("attempts",attempts);}
        else if(restoredState!=null)out.putAll(restoredState);
        super.onSaveInstanceState(out);
    }
}
