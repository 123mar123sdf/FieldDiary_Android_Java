package ru.edu.fielddiary;
import android.os.Bundle;
import android.view.View;
import org.json.JSONObject;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

public final class CardEditorActivity extends PhotoActivity {
    private String id;private JSONObject draft;private boolean ready=false;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);id=state!=null?state.getString("editingId"):recordId();if(id.isEmpty())id=Models.id();
        draft=state!=null&&state.containsKey("draft")?object(state.getString("draft")):null;
        setup(R.layout.activity_card_editor,recordId().isEmpty()?"Новая карточка":"Изменить карточку");bindPhoto();
        findViewById(R.id.delete).setVisibility(recordId().isEmpty()?View.GONE:View.VISIBLE);
        findViewById(R.id.delete).setOnClickListener(v->confirmDelete(id,"Удалить карточку?",ok->finish()));
        findViewById(R.id.save).setOnClickListener(v->save());
        if(draft!=null)fill(draft);
        else if(recordId().isEmpty())fill(obj("question","","answer","","image",""));
        else work(()->app.store.get(recordId()),r->{if(r==null){toast("Карточка уже удалена");finish();return;}fill(r.data);});
    }
    private void fill(JSONObject d){
        text(R.id.question,d.optString("question"));text(R.id.answer,d.optString("answer"));
        if(!restored||draft==null)imageName=d.optString("image");refreshPhoto();ready=true;
    }
    private JSONObject collect(){return obj("question",value(R.id.question),"answer",value(R.id.answer),"image",imageName);}
    private void save(){
        if(!ready)return;
        try{Record r=new Record(id,CARD,subject(),collect());r.validate();work(()->{app.store.save(r);return true;},ok->{toast("Карточка сохранена");finish();});}
        catch(Exception e){error(e);}
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("editingId",id);if(ready)out.putString("draft",collect().toString());else if(draft!=null)out.putString("draft",draft.toString());super.onSaveInstanceState(out);
    }
}
