package ru.edu.fielddiary;
import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.util.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

public final class EntryEditorActivity extends PhotoActivity {
    private String id;private boolean editing,ready=false,selecting=false;
    private JSONObject draft,active;private Ui.Form form;
    private List<Record> templates=new ArrayList<>();
    private long observedAt=System.currentTimeMillis();
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);editing=!recordId().isEmpty();id=state!=null?state.getString("editingId"):recordId();if(id.isEmpty())id=Models.id();
        if(state!=null&&state.containsKey("draft"))draft=object(state.getString("draft"));
        setup(R.layout.activity_entry_editor,editing?"Изменить наблюдение":"Новое наблюдение");bindPhoto();
        findViewById(R.id.delete).setVisibility(editing?View.VISIBLE:View.GONE);
        findViewById(R.id.delete).setOnClickListener(v->confirmDelete(id,"Удалить наблюдение?",ok->finish()));
        findViewById(R.id.date).setOnClickListener(v->pickDate());findViewById(R.id.save).setOnClickListener(v->save());
        work(()->{
            List<Record> topics=app.store.list(subject(),TEMPLATE);
            Record old=editing?app.store.get(recordId()):null;
            if(editing&&old==null)throw new IllegalArgumentException("Наблюдение уже удалено");
            return new Object[]{topics,old};
        },result->{
            @SuppressWarnings("unchecked") List<Record> topics=(List<Record>)result[0];templates=topics;
            Record old=(Record)result[1];JSONObject data=draft!=null?draft:old==null?null:old.data;
            if(data!=null){
                active=obj("id",data.optString("templateId"),"name",data.optString("templateName"),"instruction",data.optString("instruction"),"fields",data.optJSONArray("fields"));
                text(R.id.entryTitle,data.optString("title"));text(R.id.observer,data.optString("observer"));text(R.id.place,data.optString("place"));text(R.id.notes,data.optString("notes"));
                observedAt=data.optLong("observedAt",System.currentTimeMillis());if(!restored||draft==null)imageName=data.optString("image");
                buildForm(data.optJSONObject("values"));
            } else if(!templates.isEmpty()){useTemplate(templates.get(0));}
            else {
                toast("Сначала создайте тему в разделе «Темы»");finish();return;
            }
            configureSpinner();updateDate();refreshPhoto();ready=true;
        });
    }
    private void configureSpinner(){
        Spinner spinner=findViewById(R.id.templateSpinner);List<String> names=new ArrayList<>();
        // Сохранённая схема не заменяется новой автоматически: старые записи остаются читаемыми.
        if(editing){names.add(active.optString("name")+" (сохранённая форма)");spinner.setAdapter(Ui.spinnerAdapter(this,names));spinner.setEnabled(false);return;}
        int selected=0;String selectedId=active.optString("id");boolean found=false;
        for(int i=0;i<templates.size();i++){names.add(templates.get(i).title());if(templates.get(i).id.equals(selectedId)){selected=i;found=true;}}
        if(!found){templates.add(0,new Record(selectedId,TEMPLATE,subject(),Models.copy(active)));names.add(0,active.optString("name")+" (черновик)");selected=0;}
        spinner.setAdapter(Ui.spinnerAdapter(this,names));selecting=true;spinner.setSelection(selected);
        spinner.post(()->selecting=false);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> parent){}
            public void onItemSelected(android.widget.AdapterView<?> parent,View view,int pos,long itemId){
                if(selecting||pos<0||pos>=templates.size())return;Record next=templates.get(pos);
                if(next.id.equals(active.optString("id")))return;
                new AlertDialog.Builder(EntryEditorActivity.this).setTitle("Сменить тему?")
                    .setMessage("Значения специальных полей будут очищены. Название, дата, место, примечания и фото сохранятся.")
                    .setPositiveButton("Сменить",(d,w)->useTemplate(next))
                    .setNegativeButton(R.string.cancel,(d,w)->restoreSelection()).setOnCancelListener(d->restoreSelection()).show();
            }
        });
    }
    private void restoreSelection(){
        Spinner spinner=findViewById(R.id.templateSpinner);
        for(int i=0;i<templates.size();i++)if(templates.get(i).id.equals(active.optString("id"))){selecting=true;spinner.setSelection(i);spinner.post(()->selecting=false);break;}
    }
    private void useTemplate(Record t){
        active=Models.copy(t.data);try{active.put("id",t.id);}catch(JSONException e){throw new IllegalArgumentException(e);}
        buildForm(new JSONObject());
    }
    private void buildForm(JSONObject values){
        text(R.id.task,active.optString("instruction"));form=new Ui.Form(this,(LinearLayout)findViewById(R.id.fields),active.optJSONArray("fields"),values==null?new JSONObject():values);
    }
    private void updateDate(){text(R.id.date,Ui.date(observedAt));}
    private void pickDate(){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(observedAt);
        new DatePickerDialog(this,(view,y,m,d)->{
            c.set(y,m,d);new TimePickerDialog(this,(time,h,min)->{
                c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);observedAt=c.getTimeInMillis();updateDate();
            },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private JSONObject collect(){
        if(active==null)return draft==null?new JSONObject():draft;
        return obj("title",value(R.id.entryTitle),"observer",value(R.id.observer),"place",value(R.id.place),
            "notes",value(R.id.notes),"observedAt",observedAt,"image",imageName,
            "templateId",active.optString("id"),"templateName",active.optString("name"),"instruction",active.optString("instruction"),
            "fields",active.optJSONArray("fields"),"values",form==null?new JSONObject():form.values());
    }
    private void save(){
        if(!ready)return;
        try{form.validate();Record r=new Record(id,ENTRY,subject(),collect());r.validate();
            work(()->{app.store.save(r);return true;},ok->{toast("Наблюдение сохранено");finish();});}
        catch(Exception e){error(e);}
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("editingId",id);if(active!=null)out.putString("draft",collect().toString());else if(draft!=null)out.putString("draft",draft.toString());
        super.onSaveInstanceState(out);
    }
}
