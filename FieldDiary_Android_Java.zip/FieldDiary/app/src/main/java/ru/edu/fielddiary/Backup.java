package ru.edu.fielddiary;
import android.content.Context;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import static ru.edu.fielddiary.Models.*;
import ru.edu.fielddiary.Models.Record;

/** Формат .zip: manifest.json + images/UUID.jpg. Распаковка ограничена по размеру. */
public final class Backup {
    private Backup(){}
    private static final int MAX_IMAGE=8*1024*1024, MAX_JSON=16*1024*1024;
    private static final long MAX_TOTAL=128L*1024*1024;
    public static int exportData(Context c,Store store,Uri uri,boolean materials) throws Exception {
        List<Record> records=store.list(null,null);JSONArray array=new JSONArray();Set<String> photos=new LinkedHashSet<>();
        for(Record r:records){
            if(materials&&r.kind.equals(ENTRY))continue;
            r.validate();array.put(r.packed());if(!r.image().isEmpty())photos.add(r.image());
        }
        byte[] json=obj("format","fielddiary","version",1,"scope",materials?"materials":"all","records",array)
            .toString().getBytes(StandardCharsets.UTF_8);
        need(json.length<=MAX_JSON,"Слишком большой объём текстовых данных для резервной копии");
        long total=json.length;
        for(String name:photos){File f=ImageStore.file(c,name);need(f.isFile()&&f.length()>0,"Не найдено изображение: "+name);
            need(f.length()<=MAX_IMAGE,"Слишком большой файл изображения");total+=f.length();}
        need(total<=MAX_TOTAL,"Копия больше 128 МБ. Удалите ненужные фото или экспортируйте только материалы.");
        OutputStream output=c.getContentResolver().openOutputStream(uri,"wt");
        if(output==null)throw new IOException("Нет доступа к выбранному файлу");
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(output))){
            zip.putNextEntry(new ZipEntry("manifest.json"));zip.write(json);zip.closeEntry();
            byte[] buffer=new byte[16384];
            for(String name:photos){zip.putNextEntry(new ZipEntry("images/"+name));
                try(InputStream in=new FileInputStream(ImageStore.file(c,name))){int n;while((n=in.read(buffer))!=-1)zip.write(buffer,0,n);}
                zip.closeEntry();
            }
        }
        return array.length();
    }
    public static String importData(Context c,Store store,Uri uri,boolean updateMaterials) throws Exception {
        File stage=new File(c.getCacheDir(),"import_"+id());
        need(stage.mkdirs(),"Не удалось создать временную папку");
        List<File> created=new ArrayList<>();boolean committed=false;
        try {
            Map<String,File> imageFiles=new HashMap<>();Set<String> names=new HashSet<>();
            byte[] manifest=null;long total=0;int count=0;
            InputStream source=c.getContentResolver().openInputStream(uri);
            if(source==null)throw new IOException("Нет доступа к архиву");
            try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(source))){
                ZipEntry entry;byte[] buffer=new byte[16384];
                while((entry=zip.getNextEntry())!=null){
                    String name=entry.getName();
                    need(++count<=MAX_RECORDS+1,"Слишком много файлов в архиве");
                    need(!entry.isDirectory()&&names.add(name),"Повторяющийся или недопустимый элемент архива");
                    boolean isManifest=name.equals("manifest.json");
                    need(isManifest||name.matches("images/[a-f0-9-]{36}\\.jpg"),"Неизвестный файл в архиве");
                    int limit=isManifest?MAX_JSON:MAX_IMAGE;int size=0;
                    ByteArrayOutputStream json=isManifest?new ByteArrayOutputStream():null;
                    File file=isManifest?null:new File(stage,name.substring(7));
                    try(OutputStream out=isManifest?json:new FileOutputStream(file)){
                        int n;while((n=zip.read(buffer))!=-1){size+=n;total+=n;
                            need(size<=limit&&total<=MAX_TOTAL,"Архив слишком большой или повреждён");out.write(buffer,0,n);}
                    }
                    if(isManifest)manifest=json.toByteArray();else imageFiles.put(name.substring(7),file);
                    zip.closeEntry();
                }
            }
            need(manifest!=null,"В архиве нет manifest.json");
            JSONObject root=new JSONObject(new String(manifest,StandardCharsets.UTF_8));
            need(root.optString("format").equals("fielddiary")&&root.optInt("version")==1,"Неподдерживаемый формат архива");
            JSONArray array=root.getJSONArray("records");need(array.length()<=MAX_RECORDS,"Слишком много записей");
            List<Record> records=new ArrayList<>();Set<String> ids=new HashSet<>();int skipped=0;
            for(int i=0;i<array.length();i++){
                Record r=Record.unpack(array.getJSONObject(i));r.validate();need(ids.add(r.id),"Повтор идентификатора в архиве");
                if(!r.image().isEmpty())need(imageFiles.containsKey(r.image()),"В архиве отсутствует изображение");
                Record existing=store.get(r.id);
                if(existing!=null&&(!updateMaterials||r.kind.equals(ENTRY))){skipped++;continue;}
                if(existing!=null)need(existing.kind.equals(r.kind)&&existing.subject.equals(r.subject),"Конфликт типов материалов в архиве");
                records.add(r);
            }
            Map<String,String> renamed=new HashMap<>();
            for(Record r:records){String old=r.image();if(old.isEmpty())continue;
                String name=renamed.get(old);
                if(name==null){name=ImageStore.importImage(c,Uri.fromFile(imageFiles.get(old)));renamed.put(old,name);created.add(ImageStore.file(c,name));}
                r.data.put("image",name);
            }
            int imported=store.addImported(records,updateMaterials);committed=true;
            return "Добавлено / обновлено: "+imported+". Пропущено совпадений: "+skipped+". "+(updateMaterials?"Совпавшие темы и карточки обновлены. Существующие наблюдения не перезаписаны.":"Существующие записи не перезаписаны.");
        } finally {
            if(!committed)for(File f:created)f.delete();
            File[] files=stage.listFiles();if(files!=null)for(File f:files)f.delete();stage.delete();
        }
    }
}
